<?php
/**
 * Post types configuration.
 *
 * @package HivePress\Configs
 */

use HivePress\Helpers as hp;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

return [
	'testimonial' => [
		'public'    => false,
		'show_ui'   => true,
		'supports'  => [ 'title', 'editor', 'thumbnail' ],
		'menu_icon' => 'dashicons-testimonial',

		'labels'    => [
			'name'               => esc_html__( 'Testimonials', 'hivepress-testimonials' ),
			'singular_name'      => esc_html__( 'Testimonial', 'hivepress-testimonials' ),
			'add_new_item'       => esc_html__( 'Add Testimonial', 'hivepress-testimonials' ),
			'add_new'            => esc_html_x( 'Add New', 'testimonial', 'hivepress-testimonials' ),
			'edit_item'          => esc_html__( 'Edit Testimonial', 'hivepress-testimonials' ),
			'new_item'           => esc_html__( 'Add Testimonial', 'hivepress-testimonials' ),
			'all_items'          => esc_html__( 'Testimonials', 'hivepress-testimonials' ),
			'search_items'       => esc_html__( 'Search Testimonials', 'hivepress-testimonials' ),
			'not_found'          => esc_html__( 'No testimonials found.', 'hivepress-testimonials' ),
			'not_found_in_trash' => esc_html__( 'No testimonials found.', 'hivepress-testimonials' ),
		],
	],
];
