<?php
/**
 * Styles configuration.
 *
 * @package HivePress\Configs
 */

use HivePress\Helpers as hp;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

return [
	'testimonials_frontend' => [
		'handle'  => 'hivepress-testimonials-frontend',
		'src'     => hivepress()->get_url( 'testimonials' ) . '/assets/css/frontend.min.css',
		'version' => hivepress()->get_version( 'testimonials' ),
		'scope'   => [ 'frontend', 'editor' ],
	],
];
